 # Python quiz game

questions = ("How many elements are in the periodic table?: ",
            "Which animal lays the lagest eggs?: ",
            "What is the most abundent gas in Earth's atmosphere?: ",
            "How many bones are in the human body??: ",
            "Which planet in the solar system is the hottest?: ")

# options 
options = (("A. 106", "B. 34", "C. 112", "D. 31"),
          ("A. Whale ", "B. Crocodile", "C. Elephent", "D. Ostrich"),
          ("A. Nitrogen", "B. Oxygen", "C. Carbon dioxide", "D. Hydrogen"),
          ("A. 207", "B. 91", "C. 342", "D. 79"),
          ("A. Mecury", "B. Vennus", "C. Earth", "D. Mars"),
)
# Answers
answers = ("A", "D", "A", "A", "B")
guesses = []
score = 0
question_num = 0

for question in questions:
    print("........................")
    print(question)

    
    for option in options[question_num]:
        print(option)
    
    guess = input("Enter(A, B, C, D): ").upper()
    guesses.append(guess)
    if guess == answers[question_num]:
        score += 1
        print("Correct")
        
    else:
        print("Incorrect")
        print(f"{answers[question_num]} is the correct answer")
    question_num += 1
            
        
print(".....................")
print("      RESULTS        ")
print(".....................")

print("answers: ", end="")
for answer in answers:
    print(answer, end="")
print()

print("guesses: ", end="")
for guess in guesses:
    print(answer, end="")
print()

score = int(score / len(questions) * 100)
print(f"your score is: {score}%")

