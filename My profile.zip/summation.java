import java.util.*;
public class Calculator{
    public static void main(String[] args){
        scanner sc = new Scanner(System.in);

        System.out.println("Enter two numbers: ");
        int a = sc.nextlnt();
        int b = sc.nextlnt();
        System.out.println("Enter any operator you want to use (+,-,/,%)");
        char op = sc.next().charAt(0);
        switch(op){
            case "+": System.out.println(a+b);
                    break;
            case "-": System.out.println(a-b);
                    break;
            case "x": System.out.println(a*b);
                    break;
            case "/": System.out.println(a/b);
                    break;
            case "%": System.out.println(a%b);
                    break;
            default: System.out.println("Invalid input");
        }
    }
}